#Get User's name and save it to var, name

name=input("What is your name? ")

#Display customized welcome message for user


print("Hello, "+name+"! You will love SDN!")
