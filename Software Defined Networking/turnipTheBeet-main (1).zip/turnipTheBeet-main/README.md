# turnipTheBeet
Class templates for learning network automation
